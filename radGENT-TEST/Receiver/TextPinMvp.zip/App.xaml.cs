using System.Windows;

namespace TextPinMvp;

public partial class App : Application
{
}
